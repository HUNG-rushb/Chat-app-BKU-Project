const userQuery = require("./USER.js");
const postQuery = require("./POST.js");
// const commentQuery = require('./COMMENT.js');

const Query = {
  ok(parent, args, { prisma }, info) {
    // if (!args.query) {
    //   return db.users;
    // }
    return { ok: "ok" };
  },
  // User
  ...userQuery,
  // Post
  ...postQuery,
  // Comment
  // ...commentQuery,
};

module.exports = Query;
