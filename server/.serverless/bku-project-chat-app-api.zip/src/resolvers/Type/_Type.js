const User = require('./User___.js');
const Post = require('./Post___.js');
// const Comment = require('./Comment___.js');

const Type = {
  User,
  Post,
  // Comment,
};

module.exports = Type;
