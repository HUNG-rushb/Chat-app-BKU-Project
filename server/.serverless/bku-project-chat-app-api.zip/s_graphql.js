
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'duyhung',
  applicationName: 'bku-project',
  appUid: 'qQ3c7Qv5zx7G2gjYyd',
  orgUid: '58b592b3-32f0-4333-92df-615043708d99',
  deploymentUid: '72a6edd9-f5ad-4a2a-993a-c09f9493e250',
  serviceName: 'bku-project-chat-app-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'bku-project-chat-app-api-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./src/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}